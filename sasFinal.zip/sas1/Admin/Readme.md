 
**Admin Login Details**
Email : super@admin
Password: admin

**Teacher Login Details** 
Email : class@six
Password: pass123

